// Ansicht „Heute“: eine Seite nach der anderen.
// Morgens beginnt es mit dem Morgeneintrag, abends mit dem Abendeintrag.

import { t, inhalt, fuelle } from '../inhalte.js';
import { esc, zahl, leseZahl, zufall, toast, sternchen, ausKey, plusTage, $, $$ } from '../util.js';
import {
  einstellungen, heuteKey, tag, aendereTag, morgenErledigt, letzterWert,
  summenFesthalten, pauseGenommen, freudeListe, freudeNach, freudeGenossen,
  beobachtungen, speichereBeobachtung, experimentJetzt, experimentVorbei,
} from '../daten.js';
import { infoKnopf, infoFuerExperiment } from '../info.js';
import { rueckblicke, ungelesenerRueckblick, datumKurz } from '../rueckblick.js';
import { gewichtModus, sprunghaft, gesundheitHat, mehrAnbieten, profil, markiereProfil } from '../profil.js';
import { api } from '../speicher.js';
import { zeigeSeiten, textBloecke } from '../seiten.js';
import { feldKopf, stundenText, bestaetige } from './teile.js';
import { stand } from '../weg.js';
import { katalogEintrag } from '../experimente.js';

let morgenBearbeiten = false;
let abendBearbeiten = false;
let mehrEintragen = false;
let vorschlag = null;
let steuerung = null;

function tageszeit(ctx) {
  if (ctx.abendmodus()) return 'abend';
  const stunde = new Date().getHours();
  if (stunde < 4) return 'nacht';
  if (stunde < 11) return 'morgen';
  if (stunde < 17) return 'tag';
  return 'abend';
}

function haltungsSatz(datum) {
  const saetze = inhalt('texte.haltung.saetze', []);
  if (!saetze.length) return '';
  return saetze[Math.floor(ausKey(datum).getTime() / 86400000) % saetze.length];
}

// Soll heute nach dem Gewicht gefragt werden?
function gewichtHeute(datum) {
  const modus = gewichtModus();
  if (modus === 'aus') return false;
  if (modus === 'woche') return ausKey(datum).getDay() === Number(einstellungen().wiegetag ?? 1);
  return true;
}

/* ---------- Seiten ---------- */

// Zu welchem Abschnitt eine Seite gehört. Daraus entstehen die Zeile „Morgen · 2 von 3“ und die Übersicht.
function schrittVon(id) {
  if (id === 'start') return 'tag';
  if (id.startsWith('morgen')) return 'morgen';
  if (id === 'experiment' || id.startsWith('beobachtung')) return 'experiment';
  return ['freude', 'summen', 'abend'].includes(id) ? id : null;
}

const SCHRITT_SYMBOL = { morgen: '☀️', experiment: '🧪', freude: '💛', summen: '🌀', abend: '🌙' };

// Was heute schon eingetragen ist. Offenes wird nicht hervorgehoben, nur Erledigtes bekommt ein leises Häkchen.
function schrittErledigt(schritt, heute, datum) {
  if (schritt === 'morgen') return morgenErledigt(heute);
  if (schritt === 'experiment') return beobachtungen().some((b) => b.datum === datum);
  if (schritt === 'freude') return (heute.freudeGenutzt || []).length > 0;
  if (schritt === 'summen') return (heute.summen || []).length > 0;
  if (schritt === 'abend') return Boolean(heute.anspannung);
  return false;
}

function tagesUebersicht(gruppen, heute, datum) {
  const gesehen = new Set();
  const zeilen = [];
  for (const g of gruppen) {
    const schritt = schrittVon(g.id);
    if (!schritt || schritt === 'tag' || gesehen.has(schritt)) continue;
    gesehen.add(schritt);
    const fertig = schrittErledigt(schritt, heute, datum);
    zeilen.push(`
      <button type="button" class="tag-schritt${fertig ? ' erledigt' : ''}" data-aktion="gehe" data-ziel="${esc(g.id)}">
        <span class="tag-schritt-symbol" aria-hidden="true">${SCHRITT_SYMBOL[schritt]}</span>
        <span class="tag-schritt-name">${esc(t(`heute.schritt_${schritt}`))}</span>
        <span class="tag-schritt-zeichen">${fertig ? `<span aria-hidden="true">✓</span><span class="nur-vorleser">${esc(t('heute.schritt_erledigt'))}</span>` : '<span aria-hidden="true">›</span>'}</span>
      </button>`);
  }
  if (!zeilen.length) return '';
  return `<div class="tag-uebersicht">
    <p class="feld-name">${esc(t('heute.uebersicht_titel'))}</p>
    <div class="tag-liste">${zeilen.join('')}</div>
  </div>`;
}

function startSeite(datum, zeit, uebersicht = '') {
  const name = einstellungen().name || '';
  const gruss = t(`begruessung.${zeit === 'nacht' ? 'nacht' : zeit}`, { name }).replace(/,\s*\./, '.');
  const d = ausKey(datum);
  const neu = ungelesenerRueckblick();
  const bloecke = [
    `<p class="ueberzeile">${esc(t('heute.datum', {
      wochentag: inhalt('texte.allgemein.wochentage')[d.getDay()],
      tag: d.getDate(),
      monat: inhalt('texte.allgemein.monate')[d.getMonth()],
    }))}</p>`,
    `<h1>${esc(gruss)}</h1>`,
    `<p class="haltung">${esc(haltungsSatz(datum))}</p>`,
  ];
  const art = sessionStorage.getItem('emona-erinnerung');
  if (art && sprunghaft()) {
    bloecke.push(`
      <div class="hinweis-kasten">
        <p>${esc(t('erinnerung_spaeter.frage'))}</p>
        <button class="knopf knopf-zweit" data-aktion="spaeter-erinnern" data-art="${esc(art)}">${esc(t('erinnerung_spaeter.knopf'))}</button>
      </div>`);
  }
  // Die Übersicht steht nach „Später erinnern“, damit dieser Knopf nach einer Erinnerung sofort sichtbar ist.
  if (uebersicht) bloecke.push(uebersicht);
  if (neu) {
    bloecke.push(`
      <div class="hinweis-kasten karte-rueckblick">
        <h2><span class="symbol" aria-hidden="true">✨</span> ${esc(t('rueckblick.neu_titel'))}</h2>
        <p>${esc(t('rueckblick.neu_text'))}</p>
        <a class="knopf knopf-haupt" href="#rueckblick/${neu.nummer}">${esc(t('rueckblick.oeffnen'))}</a>
      </div>`);
  }
  if (mehrAnbieten()) {
    // Einmal, an einem Tag: die neuen Fragen sanft anbieten.
    if (!profil().mehrAngeboten) markiereProfil({ mehrAngeboten: heuteKey() });
    bloecke.push(`
      <div class="hinweis-kasten">
        <h2>${esc(t('kennenlernen.mehr_titel'))}</h2>
        <p>${esc(t('kennenlernen.mehr_kachel'))}</p>
        <div class="knopf-spalte eng">
          <a class="knopf knopf-zweit" href="#kennenlernen/mehr">${esc(t('kennenlernen.mehr_los'))}</a>
          <button type="button" class="knopf-text leise-knopf" data-aktion="mehr-spaeter">${esc(t('kennenlernen.mehr_spaeter'))}</button>
        </div>
      </div>`);
  }
  const st = stand();
  if (st.eintraege || st.experiment) {
    // „So läuft es gerade“: eine ruhige Kachel, die in „Mein Weg“ führt.
    const zeilen = [
      st.experiment
        ? t('weg.kachel_experiment', { titel: st.experiment.titel, ...(st.tag || { tag: 1, von: 1 }) })
        : t('weg.kachel_kein_experiment'),
      `${st.eintraege === 1 ? t('weg.eintraege_eins') : t('weg.eintraege', { anzahl: st.eintraege })} ${st.bisRueckblick === 1 ? t('weg.bis_rueckblick_eins') : t('weg.bis_rueckblick', { anzahl: st.bisRueckblick })}`,
    ];
    bloecke.push(`
      <a class="weg-kachel" href="#verlauf">
        <span class="weg-kachel-titel">${esc(t('weg.kachel_titel'))}</span>
        ${zeilen.map((z) => `<span class="weg-kachel-zeile">${esc(z)}</span>`).join('')}
        <span class="weg-kachel-link">${esc(t('weg.kachel_link'))} →</span>
      </a>`);
  } else if (!rueckblicke().length) {
    bloecke.push(`<p class="leise klein block-abstand">${esc(t('rueckblick.hinweis_sieben'))} ${infoKnopf('rueckblick')}</p>`);
  }
  return { id: 'start', bloecke, mitte: true };
}

function morgenSeiten(heute, datum) {
  if (morgenErledigt(heute) && !morgenBearbeiten) {
    return [{
      id: 'morgen',
      mitte: true,
      bloecke: [
        `<h2>${esc(t('morgen.fertig_titel'))}</h2>`,
        ...textBloecke(t('morgen.fertig_text')),
        `<button class="knopf-text" data-aktion="morgen-aendern">${esc(t('morgen.aendern'))}</button>`,
      ],
    }];
  }
  const kurz = sprunghaft() && !mehrEintragen && !morgenBearbeiten;
  // Am Wiegetag hat das Gewicht eine eigene Seite, auch in der kurzen Fassung.
  // An anderen Tagen steht es freiwillig über der Taille, solange es nicht ausgeschaltet ist.
  const wiegetag = gewichtHeute(datum);
  const gewichtFreiwillig = !wiegetag && gewichtModus() !== 'aus';
  const koerperFrage = t(gewichtFreiwillig ? 'morgen.koerper_zusammenfassung_gewicht' : 'morgen.koerper_zusammenfassung');
  const gewicht = heute.gewicht !== undefined ? zahl(heute.gewicht, 1) : '';
  const einschlaf = heute.einschlafzeit ?? letzterWert('einschlafzeit') ?? '23:00';
  const dauer = heute.schlafdauer ?? letzterWert('schlafdauer') ?? 7;
  const taille = heute.taille !== undefined ? zahl(heute.taille, 1).replace(/,0$/, '') : '';
  const speichern = `<button class="knopf knopf-haupt" data-aktion="morgen-speichern">${esc(t('morgen.speichern'))}</button>`;
  const kopf = [`<h2>${esc(t('morgen.titel'))}</h2>`, `<p class="leise">${esc(t('morgen.einleitung'))}</p>`];

  const gewichtFeld = `<label class="feld">
          ${feldKopf(t('morgen.gewicht'), 'gewicht')}
          <span class="eingabe-mit-einheit">
            <input name="gewicht" type="text" inputmode="decimal" autocomplete="off" value="${esc(gewicht)}" aria-describedby="gewicht-hilfe">
            <span class="einheit">${esc(t('morgen.gewicht_einheit'))}</span>
          </span>
          <span class="feld-hilfe" id="gewicht-hilfe">${esc(t('morgen.gewicht_hilfe'))}</span>
        </label>`;
  const gewichtHinweis = gesundheitHat('schilddruese') || gesundheitHat('medikamente') ? `<p class="hinweis klein">${esc(t('gesundheit.gewicht_hinweis'))}</p>` : '';

  const seiten = [];
  if (wiegetag) {
    seiten.push({ id: 'morgen-gewicht', bloecke: [...kopf, gewichtFeld, gewichtHinweis] });
  }
  seiten.push({
    id: 'morgen-schlaf',
    bloecke: [
      ...(seiten.length ? [] : kopf),
      `<label class="feld">
        ${feldKopf(t('morgen.einschlafzeit'), 'einschlafzeit')}
        <input name="einschlafzeit" type="time" value="${esc(einschlaf)}">
      </label>`,
      `<div class="feld">
        ${feldKopf(t('morgen.schlafdauer'), 'schlafdauer', 'dauer-name')}
        <div class="stepper" role="group" aria-labelledby="dauer-name">
          <button type="button" class="stepper-knopf" data-aktion="dauer" data-schritt="-0.25" aria-label="${esc(t('morgen.weniger'))}">−</button>
          <output class="stepper-wert" data-dauer="${dauer}">${esc(stundenText(dauer))}</output>
          <button type="button" class="stepper-knopf" data-aktion="dauer" data-schritt="0.25" aria-label="${esc(t('morgen.mehr'))}">+</button>
        </div>
      </div>`,
      kurz ? speichern : '',
      kurz ? `<button class="knopf-text" data-aktion="mehr-eintragen">${esc(koerperFrage)}</button>` : '',
    ],
  });
  if (!kurz) {
    seiten.push({
      id: 'morgen-koerper',
      bloecke: [
        `<p class="feld-name">${esc(koerperFrage)}</p>`,
        gewichtFreiwillig ? gewichtFeld : '',
        gewichtFreiwillig ? gewichtHinweis : '',
        `<label class="feld">
          ${feldKopf(t('morgen.taille'), 'taille')}
          <span class="eingabe-mit-einheit">
            <input name="taille" type="text" inputmode="decimal" autocomplete="off" value="${esc(taille)}" aria-describedby="taille-hilfe">
            <span class="einheit">${esc(t('morgen.taille_einheit'))}</span>
          </span>
          <span class="feld-hilfe" id="taille-hilfe">${esc(t('morgen.taille_hilfe'))}</span>
        </label>`,
        `<label class="feld">
          ${feldKopf(t('morgen.koerper'), 'koerper')}
          <textarea name="koerper" rows="2" maxlength="600" placeholder="${esc(t('morgen.koerper_platzhalter'))}">${esc(heute.koerper || '')}</textarea>
        </label>`,
        speichern,
      ],
    });
  }
  return seiten;
}

function mitAblage(v = experimentJetzt()) {
  return Boolean(v && !experimentVorbei(v) && katalogEintrag(v.id)?.ablage);
}

function experimentSeite() {
  const v = experimentJetzt();
  if (!v) {
    return {
      id: 'experiment',
      mitte: true,
      bloecke: [
        `<h2>${esc(t('experimentwahl.keins_titel'))} ${infoKnopf('experiment')}</h2>`,
        ...textBloecke(t('experimentwahl.keins_text')),
        `<a class="knopf knopf-haupt" href="#experiment">${esc(t('experimentwahl.keins_knopf'))}</a>`,
      ],
    };
  }
  const vorbei = experimentVorbei(v);
  const bloecke = [
    `<p class="ueberzeile">${esc(vorbei ? t('experiment.titel') : t('experimentwahl.laeuft', { ende: datumKurz(v.ende) }))}</p>`,
    `<h2 class="experiment-name">${esc(v.titel)} ${infoKnopf(v.info || infoFuerExperiment(v.titel))}</h2>`,
  ];
  if (v.beschreibung) bloecke.push(...textBloecke(v.beschreibung));
  // Beim Experiment „Abends ist alles erledigt“ liegt hier, was gestern Abend abgelegt wurde.
  const gestern = mitAblage(v) ? tag(plusTage(heuteKey(), -1)).abgelegt : '';
  if (gestern) {
    bloecke.push(`<div class="hinweis-kasten abgelegt">
      <p class="feld-name">${esc(t('experiment.abgelegt_titel'))}</p>
      ${textBloecke(gestern, 'abgelegt-text').join('')}
      <p class="leise klein">${esc(t('experiment.abgelegt_text'))}</p>
    </div>`);
  }
  if (v.wann) bloecke.push(`<p>${esc(t('experimentwahl.eigen_wann_anzeige', { text: v.wann }))}</p>`);
  if (v.woran) bloecke.push(`<p>${esc(t('experimentwahl.eigen_woran_anzeige', { text: v.woran }))}</p>`);
  bloecke.push(`<p class="leise klein">${esc(vorbei ? t('experimentwahl.vorbei') : t('experiment.hinweis'))}</p>`);
  bloecke.push(`<a class="knopf-text" href="#experiment">${esc(t('experimentwahl.wechseln'))}</a>`);
  return { id: 'experiment', klasse: 'seite-experiment', bloecke };
}

function beobachtungsSeiten(datum) {
  const alle = beobachtungen();
  const heutige = alle.filter((b) => b.datum === datum);
  const seiten = [{
    id: 'beobachtung',
    bloecke: [
      `<label class="feld">
        ${feldKopf(t('experiment.notiz_label'), 'beobachtungen')}
        <textarea name="beobachtung" rows="3" maxlength="1500" placeholder="${esc(t('experiment.notiz_platzhalter'))}" aria-describedby="beobachtung-hilfe"></textarea>
        <span class="feld-hilfe" id="beobachtung-hilfe">${esc(t('experiment.notiz_hilfe'))}</span>
      </label>`,
      `<button class="knopf knopf-zweit" data-aktion="beobachtung-speichern">${esc(t('experiment.notiz_speichern'))}</button>`,
      alle.some((b) => b.datum !== datum) ? `<a class="knopf-text" href="#notizen">${esc(t('experiment.fruehere_zeigen'))}</a>` : '',
    ],
  }];
  if (heutige.length) {
    seiten.push({
      id: 'beobachtung-heute',
      bloecke: [
        `<p class="feld-name">${esc(t('experiment.heute_notiert'))}</p>`,
        ...heutige.map((b) => `<div class="beobachtung">${textBloecke(b.text, 'beobachtung-text').join('')}</div>`),
      ],
    });
  }
  return seiten;
}

function freudeSeite(heute) {
  const plaetze = (heute.freudePlaetze || []).map(freudeNach).filter(Boolean);
  const genutzt = new Set(heute.freudeGenutzt || []);
  const titel = `<h2><span class="symbol" aria-hidden="true">💛</span> ${esc(t('freudeplaetze.titel'))} ${infoKnopf('freude')}</h2>`;
  if (!plaetze.length) {
    return {
      id: 'freude',
      mitte: true,
      bloecke: [titel, `<p>${esc(t('freudeplaetze.leer'))}</p>`, `<a class="knopf knopf-zweit" href="#freude">${esc(t('freudeplaetze.zur_liste'))}</a>`],
    };
  }
  return {
    id: 'freude',
    bloecke: [
      titel,
      ...plaetze.map((f) => {
        const ist = genutzt.has(f.id);
        return `
          <div class="freude-platz ${ist ? 'genutzt' : ''}">
            <span class="symbol gross" aria-hidden="true">${esc(f.symbol || '💛')}</span>
            <span class="freude-titel">${esc(f.titel)}</span>
            ${ist
              ? `<span class="abzeichen"><span aria-hidden="true">★</span> ${esc(t('freudeplaetze.genutzt'))}</span>`
              : `<button class="knopf knopf-haupt knopf-klein" data-aktion="freude-genossen" data-id="${esc(f.id)}">${esc(t('freudeplaetze.nutzen'))}</button>`}
          </div>`;
      }),
      `<a class="knopf-text" href="#freude">${esc(t('freudeplaetze.zur_liste'))}</a>`,
    ],
  };
}

function summenSeite(heute) {
  if (vorschlag) {
    return {
      id: 'summen',
      mitte: true,
      bloecke: [
        `<h2>${esc(t('summen.vorschlag_titel'))}</h2>`,
        `<p class="vorschlag-text"><span class="symbol gross" aria-hidden="true">${esc(vorschlag.symbol || '💛')}</span> ${esc(vorschlag.text)}</p>`,
        `<div class="knopf-spalte">
          <button class="knopf knopf-haupt" data-aktion="pause-annehmen">${esc(t('summen.annehmen'))}</button>
          <button class="knopf knopf-zweit" data-aktion="pause-anderer">${esc(t('summen.anderer'))}</button>
          <button class="knopf-text" data-aktion="pause-spaeter">${esc(t('summen.spaeter'))}</button>
        </div>`,
      ],
    };
  }
  const anzahl = (heute.summen || []).length;
  const zusatz = anzahl === 0 ? t('summen.knopf_hilfe') : t('summen.heute_schon', { anzahl });
  return {
    id: 'summen',
    mitte: true,
    klasse: 'seite-summen',
    bloecke: [
      `<button class="summen-knopf" data-aktion="summen">
        <span class="summen-wellen" aria-hidden="true"></span>
        <span class="summen-text">${esc(t('summen.knopf'))}</span>
      </button>`,
      `<p class="summen-zusatz">${esc(zusatz)} ${infoKnopf('summen')}</p>`,
    ],
  };
}

function abendSeite(heute) {
  if (heute.anspannung && !abendBearbeiten) {
    return {
      id: 'abend',
      mitte: true,
      bloecke: [
        `<h2>${esc(t('abendeintrag.fertig_titel'))}</h2>`,
        ...textBloecke(t('abendeintrag.fertig_text')),
        `<a class="knopf knopf-haupt" href="#abend">${esc(t('abendeintrag.zum_abend'))}</a>`,
        `<button class="knopf-text" data-aktion="abend-aendern">${esc(t('abendeintrag.aendern'))}</button>`,
      ],
    };
  }
  const stufen = inhalt('texte.abendeintrag.stufen', []);
  return {
    id: 'abend',
    bloecke: [
      `<h2 id="abend-titel">${esc(t('abendeintrag.titel'))} ${infoKnopf('anspannung')}</h2>`,
      `<p class="leise">${esc(t('abendeintrag.frage'))}</p>`,
      `<div class="skala" role="radiogroup" aria-labelledby="abend-titel">
        ${stufen.map((wort, i) => `
          <button class="skala-stufe" role="radio" aria-checked="${heute.anspannung === i + 1}" data-aktion="anspannung" data-wert="${i + 1}" style="--stufe:${i + 1}">
            <span class="skala-punkt" aria-hidden="true"></span>
            <span class="skala-wort">${esc(wort)}</span>
          </button>`).join('')}
      </div>`,
      `<div class="feld">
        <p class="feld-name" id="offen-titel">${esc(t('abendeintrag.offen_frage'))}</p>
        <p class="leise klein">${esc(t('abendeintrag.offen_hilfe'))}</p>
        <div class="skala skala-offen" role="radiogroup" aria-labelledby="offen-titel">
          ${inhalt('texte.abendeintrag.offen_stufen', []).map((wort, i) => `
            <button class="skala-stufe" role="radio" aria-checked="${heute.offen === i + 1}" data-aktion="offen" data-wert="${i + 1}" style="--stufe:${i + 1}">
              <span class="skala-punkt" aria-hidden="true"></span>
              <span class="skala-wort">${esc(wort)}</span>
            </button>`).join('')}
        </div>
      </div>`,
      mitAblage() ? `<label class="feld">
        ${feldKopf(t('abendeintrag.ablage_label'), 'erledigt')}
        <textarea name="abgelegt" rows="3" maxlength="1000" placeholder="${esc(t('abendeintrag.ablage_platzhalter'))}">${esc(heute.abgelegt || '')}</textarea>
        <span class="feld-hilfe">${esc(t('abendeintrag.ablage_hilfe'))}</span>
      </label>` : '',
      `<label class="feld">
        <span class="feld-name">${esc(t('abendeintrag.satz_label'))}</span>
        <textarea name="satz" rows="2" maxlength="400" placeholder="${esc(t('abendeintrag.satz_platzhalter'))}">${esc(heute.satz || '')}</textarea>
      </label>`,
      `<button class="knopf knopf-haupt" data-aktion="abend-speichern" ${heute.anspannung ? '' : 'disabled'}>${esc(t('abendeintrag.speichern'))}</button>`,
    ],
  };
}

/* ---------- Aufbau ---------- */

export function zeige(wurzel, ctx) {
  const datum = heuteKey();
  const heute = tag(datum);
  const zeit = tageszeit(ctx);

  const gruppen = [];
  if (zeit === 'abend' || zeit === 'nacht') {
    gruppen.push(abendSeite(heute), freudeSeite(heute), summenSeite(heute), experimentSeite(), ...beobachtungsSeiten(datum));
    if (!morgenErledigt(heute) || morgenBearbeiten) gruppen.push(...morgenSeiten(heute, datum));
  } else {
    gruppen.push(...morgenSeiten(heute, datum), experimentSeite(), ...beobachtungsSeiten(datum), freudeSeite(heute), summenSeite(heute));
    if (new Date().getHours() >= 17) gruppen.push(abendSeite(heute));
  }
  gruppen.unshift(startSeite(datum, zeit, tagesUebersicht(gruppen, heute, datum)));
  for (const g of gruppen) g.schritt = schrittVon(g.id);

  steuerung = zeigeSeiten(wurzel, gruppen, { schluessel: 'heute' });
  binde(wurzel, ctx, datum);
}

function binde(wurzel, ctx, datum) {
  wurzel.onclick = async (e) => {
    const ziel = e.target.closest('[data-aktion]');
    if (!ziel) return;
    const aktion = ziel.dataset.aktion;

    if (aktion === 'dauer') {
      const ausgabe = $('.stepper-wert', wurzel);
      const neu = Math.min(14, Math.max(0, Number(ausgabe.dataset.dauer) + Number(ziel.dataset.schritt)));
      ausgabe.dataset.dauer = neu;
      ausgabe.textContent = stundenText(neu);
      return;
    }
    if (aktion === 'morgen-aendern') {
      morgenBearbeiten = true;
      ctx.zeichne();
      steuerung.gehe(wurzel.querySelector('.seite[data-gruppe^="morgen-"]')?.dataset.gruppe);
      return;
    }
    if (aktion === 'abend-aendern') { abendBearbeiten = true; ctx.zeichne(); return; }
    if (aktion === 'mehr-eintragen') {
      mehrEintragen = true;
      ctx.zeichne();
      steuerung.gehe('morgen-koerper');
      return;
    }

    if (aktion === 'morgen-speichern') {
      const feld = (name) => wurzel.querySelector(`[name="${name}"]`);
      const gewicht = feld('gewicht') ? leseZahl(feld('gewicht').value) : undefined;
      const einschlafzeit = feld('einschlafzeit')?.value || null;
      const dauer = Number($('.stepper-wert', wurzel).dataset.dauer);
      const taille = feld('taille') ? leseZahl(feld('taille').value) : undefined;
      const koerper = feld('koerper') ? feld('koerper').value.trim() : undefined;
      aendereTag(datum, (tg) => {
        if (gewicht !== undefined) {
          if (gewicht !== null && gewicht > 20 && gewicht < 400) tg.gewicht = Math.round(gewicht * 10) / 10;
          else delete tg.gewicht;
        }
        if (einschlafzeit) tg.einschlafzeit = einschlafzeit;
        else delete tg.einschlafzeit;
        tg.schlafdauer = dauer;
        if (taille !== undefined) {
          if (taille !== null && taille > 30 && taille < 250) tg.taille = Math.round(taille * 10) / 10;
          else delete tg.taille;
        }
        if (koerper !== undefined) {
          if (koerper) tg.koerper = koerper;
          else delete tg.koerper;
        }
      });
      morgenBearbeiten = false;
      mehrEintragen = false;
      ctx.zeichne();
      steuerung.gehe('experiment');
      bestaetige(t('morgen.fertig_titel'), '☀️');
      return;
    }

    if (aktion === 'summen') {
      summenFesthalten();
      neuerVorschlag();
      ctx.zeichne();
      toast(t('summen.danke'));
      return;
    }
    if (aktion === 'pause-anderer') { neuerVorschlag(vorschlag?.id); ctx.zeichne(); return; }
    if (aktion === 'pause-spaeter') { vorschlag = null; ctx.zeichne(); return; }
    if (aktion === 'pause-annehmen') {
      pauseGenommen();
      vorschlag = null;
      sternchen(ziel, 4);
      ctx.zeichne();
      toast(t('summen.angenommen'), '🍃');
      return;
    }
    if (aktion === 'freude-genossen') {
      sternchen(ziel, 6);
      freudeGenossen(ziel.dataset.id);
      ctx.zeichne();
      toast(t('freudeplaetze.belohnung'), '★');
      return;
    }
    if (aktion === 'beobachtung-speichern') {
      const text = wurzel.querySelector('[name="beobachtung"]').value.trim();
      if (!text) return;
      speichereBeobachtung(text);
      ctx.zeichne();
      steuerung.gehe('beobachtung-heute');
      bestaetige(t('experiment.gespeichert'), '🔍');
      return;
    }
    if (aktion === 'anspannung') {
      const wert = Number(ziel.dataset.wert);
      aendereTag(datum, (tg) => { tg.anspannung = wert; });
      $$('[data-aktion="anspannung"]', wurzel).forEach((s) => s.setAttribute('aria-checked', String(Number(s.dataset.wert) === wert)));
      const knopf = $('[data-aktion="abend-speichern"]', wurzel);
      if (knopf) knopf.disabled = false;
      return;
    }
    if (aktion === 'gehe') {
      steuerung.gehe(ziel.dataset.ziel);
      return;
    }
    if (aktion === 'mehr-spaeter') {
      // Ein Datum in der Vergangenheit: Die Karte kommt nicht wieder, die Fragen bleiben unter „Mehr“.
      markiereProfil({ mehrAngeboten: '2000-01-01' });
      toast(t('kennenlernen.mehr_spaeter_hinweis'));
      ctx.zeichne();
      return;
    }
    if (aktion === 'offen') {
      // Freiwillig: ein zweites Antippen derselben Stufe nimmt die Angabe wieder weg.
      const wert = Number(ziel.dataset.wert);
      let neu = wert;
      aendereTag(datum, (tg) => {
        if (tg.offen === wert) { delete tg.offen; neu = null; } else tg.offen = wert;
      });
      $$('[data-aktion="offen"]', wurzel).forEach((s) => s.setAttribute('aria-checked', String(Number(s.dataset.wert) === neu)));
      return;
    }
    if (aktion === 'abend-speichern') {
      const satz = wurzel.querySelector('[name="satz"]').value.trim();
      const abgelegt = wurzel.querySelector('[name="abgelegt"]')?.value.trim();
      aendereTag(datum, (tg) => {
        if (satz) tg.satz = satz;
        else delete tg.satz;
        if (abgelegt !== undefined) {
          if (abgelegt) tg.abgelegt = abgelegt;
          else delete tg.abgelegt;
        }
      });
      sternchen(ziel, 5);
      abendBearbeiten = false;
      ctx.zeichne();
      bestaetige(t('belohnung.abend_gelandet'));
      return;
    }
    if (aktion === 'spaeter-erinnern') {
      ziel.disabled = true;
      try {
        await api('spaeter', { art: ziel.dataset.art });
        toast(t('erinnerung_spaeter.ok'), '🔔');
      } catch {
        toast(t('erinnerung_spaeter.fehler'));
      }
      sessionStorage.removeItem('emona-erinnerung');
      ctx.zeichne();
    }
  };
}

function neuerVorschlag(ausserId) {
  const liste = freudeListe();
  let auswahl = liste.filter((f) => f.pause && f.id !== ausserId);
  if (!auswahl.length) auswahl = liste.filter((f) => f.id !== ausserId);
  if (!auswahl.length) auswahl = liste;
  const freude = zufall(auswahl);
  if (!freude) { vorschlag = null; return; }
  vorschlag = {
    id: freude.id,
    symbol: freude.symbol,
    text: fuelle(zufall(inhalt('pausenImpulse', ['{freude}'])), { freude: freude.titel }),
  };
}
