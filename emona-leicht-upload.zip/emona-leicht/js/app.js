// EMONA leicht – Start der App: Navigation, Abendmodus, Sammlung im Kopf, Service Worker.

import { ladeInhalte, inhalt, t } from './inhalte.js';
import { ablageLesen, ablageSchreiben } from './ablage.js';
import { $, esc, ganz, rattern, toast, sternchen, zeitZuMinuten } from './util.js';
import { beiAenderung, sync, syncZustand } from './speicher.js';
import { einstellungen, uebernimmAlteNotizen, uebernimmAltesExperiment, eintragsTage, experimentJetzt, heuteKey } from './daten.js';
import { profil, markiereProfil, kennenlernenBegonnen } from './profil.js';
import { seitenBeimOeffnen } from './seiten.js';
import { merkeErinnerungszeiten } from './erinnerung.js';
import { gesamt, pruefeErfolge } from './belohnung.js';
import { pruefeRueckblicke } from './rueckblick.js';
import { infoAktivieren } from './info.js';
import * as heute from './ansichten/heute.js';
import * as verlauf from './ansichten/verlauf.js';
import * as freude from './ansichten/freude.js';
import * as abend from './ansichten/abend.js';
import * as mehr from './ansichten/mehr.js';
import * as start from './ansichten/start.js';
import * as rueckblickAnsicht from './ansichten/rueckblick.js';
import * as kennenlernen from './ansichten/kennenlernen.js';
import * as experimentAnsicht from './ansichten/experiment.js';
import * as angaben from './ansichten/angaben.js';
import * as angebot from './ansichten/angebot.js';

const ANSICHTEN = {
  heute, verlauf, freude, abend, mehr,
  rueckblick: rueckblickAnsicht, kennenlernen, experiment: experimentAnsicht, angaben, angebot,
};
const NAVIGATION = ['heute', 'verlauf', 'freude', 'abend', 'mehr'];
// Unterseiten zeigen in der Navigation auf ihren Bereich.
const BEREICH = { rueckblick: 'verlauf', kennenlernen: 'mehr', angaben: 'mehr', experiment: 'heute', angebot: 'heute' };
// Kurzadressen für eine bestimmte Seite in einer Ansicht.
const ABKUERZUNGEN = { notizen: ['verlauf', 'notizen'] };
const SYMBOLE = {
  heute: '<path d="M12 3v2M12 19v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M3 12h2M19 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/><circle cx="12" cy="12" r="4"/>',
  verlauf: '<path d="M4 19h16"/><path d="M5 15l4-4 4 3 6-7"/>',
  freude: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
  abend: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  mehr: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
};

let aktuell = 'heute';
let parameter = '';
let startGruppe;
// Rückblicke und Übernahmen erst, nachdem einmal mit dem Server abgeglichen wurde.
let bereit = false;
let abendmodusAn = false;
let angezeigt = null;
let wurzel;

/* ---------- Abendmodus ---------- */

function istAbend(jetzt = new Date()) {
  const ab = zeitZuMinuten(einstellungen().abendmodusAb) ?? 21 * 60;
  const minuten = jetzt.getHours() * 60 + jetzt.getMinutes();
  return minuten >= ab || minuten < 5 * 60;
}

function modusPruefen() {
  const neu = istAbend();
  document.documentElement.dataset.modus = neu ? 'abend' : 'tag';
  const farbe = getComputedStyle(document.documentElement).getPropertyValue('--hintergrund').trim();
  $('meta[name="theme-color"]')?.setAttribute('content', farbe || (neu ? '#1b1418' : '#f6efe2'));
  if (neu !== abendmodusAn) {
    abendmodusAn = neu;
    if (aktuell === 'heute' && wurzel && !document.activeElement?.matches('input, textarea, select')) zeichne();
  }
}

/* ---------- Kopfzeile mit Sternen und Punkten ---------- */

function kopfAktualisieren() {
  const summe = gesamt();
  const sterne = $('#kopf-sterne');
  const punkte = $('#kopf-punkte');
  if (!angezeigt) {
    sterne.textContent = ganz(summe.sterne);
    punkte.textContent = ganz(summe.punkte);
  } else {
    rattern(punkte, angezeigt.punkte, summe.punkte);
    rattern(sterne, angezeigt.sterne, summe.sterne, 600);
    if (summe.sterne > angezeigt.sterne) sternchen(sterne.parentElement, 3);
  }
  angezeigt = summe;

  const z = syncZustand();
  const punkt = $('#sync-punkt');
  punkt.dataset.zustand = z.art;
  punkt.title = { lokal: t('mehr.sync_lokal'), ok: t('mehr.sync_ok'), ausstehend: t('mehr.sync_ausstehend'), fehler: t('mehr.sync_fehler'), code: t('mehr.sync_code_falsch') }[z.art] || '';
}

/* ---------- Navigation ---------- */

function baueNavigation() {
  $('#navigation').innerHTML = NAVIGATION
    .map(
      (name) => `
      <a href="#${name}" class="nav-punkt" data-ansicht="${name}">
        <svg viewBox="0 0 24 24" aria-hidden="true">${SYMBOLE[name]}</svg>
        <span>${esc(t(`nav.${name}`))}</span>
      </a>`,
    )
    .join('');
}

function ctx() {
  return {
    zeichne,
    abendmodus: () => abendmodusAn,
    param: parameter,
    start: startGruppe,
    modusPruefen,
  };
}

export function zeichne() {
  ANSICHTEN[aktuell].zeige(wurzel, ctx());
}

function route() {
  let [name, param = ''] = location.hash.slice(1).split('/');
  startGruppe = undefined;
  if (ABKUERZUNGEN[name]) [name, startGruppe] = ABKUERZUNGEN[name];
  const neu = ANSICHTEN[name] ? name : 'heute';
  parameter = decodeURIComponent(param);
  if (neu !== aktuell && ANSICHTEN[aktuell].verlassen) ANSICHTEN[aktuell].verlassen();
  if (neu !== aktuell || startGruppe) seitenBeimOeffnen(neu);
  aktuell = neu;
  // Eine frische Fläche, damit keine Ereignisse der vorherigen Ansicht hängen bleiben.
  const frisch = wurzel.cloneNode(false);
  wurzel.replaceWith(frisch);
  wurzel = frisch;
  for (const a of document.querySelectorAll('.nav-punkt')) {
    if (a.dataset.ansicht === (BEREICH[aktuell] || aktuell)) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  }
  wurzel.classList.add('neu-geoeffnet');
  setTimeout(() => frisch.classList.remove('neu-geoeffnet'), 700);
  zeichne();
  startGruppe = undefined;
}

/* ---------- Änderungen und Erfolge ---------- */

let erfolgTimer = null;
function nachAenderung(herkunft) {
  if (herkunft === 'zustand') {
    kopfAktualisieren();
    return;
  }
  clearTimeout(erfolgTimer);
  erfolgTimer = setTimeout(() => {
    const neueRueckblicke = bereit ? pruefeRueckblicke() : [];
    if (neueRueckblicke.length && herkunft !== 'server') {
      toast(t('rueckblick.toast_neu'), '✨');
      if (aktuell === 'heute' && !document.activeElement?.matches('input, textarea, select')) zeichne();
    }
    const neu = pruefeErfolge();
    kopfAktualisieren();
    // Erfolge, die durch Daten vom Server entstehen, werden still gesammelt.
    if (herkunft === 'server') return;
    const versatz = neueRueckblicke.length ? 4000 : 0;
    // Mehrere neue Erfolge auf einmal kommen gebündelt als eine einzige Meldung.
    if (neu.length === 1) setTimeout(() => toast(t('erfolge.neu', { titel: neu[0].titel }), neu[0].symbol), 1600 + versatz);
    if (neu.length > 1) setTimeout(() => toast(t('erfolge.neu_mehrere', { anzahl: neu.length }), '⭐'), 1600 + versatz);
  }, 300);
  // Daten vom Server: Ansicht neu zeichnen, solange gerade nicht getippt oder gespielt wird.
  if (herkunft === 'server') {
    const tippt = document.activeElement?.matches('input, textarea, select');
    const spielt = ANSICHTEN[aktuell].beschaeftigt?.();
    if (!tippt && !spielt) zeichne();
  }
}

// Nach dem ersten Abgleich: alte Notizen übernehmen und fällige Rückblicke anlegen.
async function vorbereiten() {
  try { await sync(); } catch { /* ohne Netz geht es lokal weiter */ }
  bereit = true;
  const nutzteAppSchon = eintragsTage().length > 0;
  uebernimmAlteNotizen();
  uebernimmAltesExperiment();
  // Erfolge aus früheren Einträgen werden still nachgetragen, ohne eine Flut von Meldungen.
  pruefeErfolge();
  kopfAktualisieren();
  merkeErinnerungszeiten();
  if (pruefeRueckblicke().length && aktuell === 'heute') zeichne();
  // Die Eingangsfragen: neu dabei direkt, wer die App schon nutzt einmal als Angebot.
  if (!profil().angeboten && !kennenlernenBegonnen()) {
    markiereProfil({ angeboten: heuteKey() });
    location.hash = nutzteAppSchon || experimentJetzt()?.uebernommen ? '#angebot' : '#kennenlernen';
  }
}

/* ---------- Service Worker und Updates ---------- */

function registriereServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  let neuLaden = false;
  navigator.serviceWorker.register('sw.js').then((reg) => {
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') reg.update().catch(() => {});
    });
  }).catch(() => {});
  // Eine neue Version wird still geladen, sobald die App im Hintergrund ist.
  const hatteKontrolle = !!navigator.serviceWorker.controller;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!hatteKontrolle) return;
    if (document.visibilityState === 'hidden') location.reload();
    else neuLaden = true;
  });
  document.addEventListener('visibilitychange', () => {
    if (neuLaden && document.visibilityState === 'hidden') location.reload();
  });
}

/* ---------- Start ---------- */

async function los() {
  wurzel = $('#inhalt');
  try {
    await ladeInhalte();
  } catch {
    wurzel.innerHTML = '<p class="karte">Ich konnte die Inhalte gerade nicht laden. Bitte prüf deine Verbindung und öffne die App noch einmal.</p>';
    return;
  }
  document.title = inhalt('app.name');
  $('#app-name').textContent = inhalt('app.name');
  $('#kopf-sterne').parentElement.setAttribute('aria-label', t('belohnung.sterne'));
  $('#kopf-punkte').parentElement.setAttribute('aria-label', t('belohnung.punkte'));
  $('#sync-punkt').setAttribute('aria-label', t('status.sync_punkt'));
  // Geöffnet über eine Erinnerung? Dann kann „Heute“ ein „Später erinnern“ anbieten.
  const adresse = new URL(location.href);
  const erinnerung = adresse.searchParams.get('erinnerung');
  if (erinnerung) {
    sessionStorage.setItem('emona-erinnerung', erinnerung);
    adresse.searchParams.delete('erinnerung');
    history.replaceState(null, '', adresse.pathname + adresse.search + adresse.hash);
  }
  navigator.serviceWorker?.addEventListener('message', (e) => {
    if (!e.data?.erinnerung) return;
    sessionStorage.setItem('emona-erinnerung', e.data.erinnerung);
    if (aktuell === 'heute') zeichne();
  });
  baueNavigation();
  infoAktivieren();
  // Dreht sich das Handy oder ändert sich die Größe, werden die Seiten neu aufgeteilt.
  let groesse = `${innerWidth}x${innerHeight}`;
  let groesseTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(groesseTimer);
    groesseTimer = setTimeout(() => {
      const neu = `${innerWidth}x${innerHeight}`;
      const tippt = document.activeElement?.matches('input, textarea, select');
      if (neu === groesse || tippt || ANSICHTEN[aktuell].beschaeftigt?.() || !wurzel) return;
      groesse = neu;
      zeichne();
    }, 300);
  });
  modusPruefen();
  setInterval(modusPruefen, 30 * 1000);
  kopfAktualisieren();
  beiAenderung(nachAenderung);

  const offlineHinweis = () => {
    if (!navigator.onLine) toast(t('status.offline'));
    else sync();
  };
  window.addEventListener('online', offlineHinweis);
  window.addEventListener('offline', offlineHinweis);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      modusPruefen();
      sync();
      if (aktuell === 'heute' && !document.activeElement?.matches('input, textarea, select')) zeichne();
    }
  });

  const starten = () => {
    ablageSchreiben('gestartet', '1');
    document.body.classList.remove('erststart');
    window.addEventListener('hashchange', route);
    route();
    vorbereiten();
  };

  let gestartet = false;
  gestartet = ablageLesen('gestartet') === '1';
  if (!gestartet) {
    document.body.classList.add('erststart');
    start.zeige(wurzel, { fertig: starten });
  } else {
    starten();
  }
  registriereServiceWorker();
}

los();
